import java.io.FileNotFoundException;
import java.io.IOException;

import com.sun.tools.javah.resources.l10n;

// simple substring match

class solution {
    public boolean containBytes(byte[] pattern, byte[] text) {
        for (int i = 0; i < text.length - pattern.length; i ++) {
            int j = 0;
            while (j < pattern.length && pattern[j] == text[i + j])
                j ++;
            if (j == pattern.length) return true;
        }
        return false;
    }
}

//use rolling hash to check substring match

class RollingHash {
    private final int LARGE_PRIME = 105613
    private final int a;
    private int h = 1;
    private final int WINDOW_LENGTH;

    private long currHashValue;

    public RollingHash(int a, byte[] initialBytes) {
        this.a = a;
        this.WINDOW_LENGTH = initialBytes.length;

        for (int i = 0; i < WINDOW_LENGTH - 1; i ++) {
            h = (h * a) % LARGE_PRIME;
        }

        currHashValue = hash(initialBytes);
    }

    public long hash(byte[] bytes) {
        int hashVal = 0;

        for (int i =0; i < bytes.length; i ++) {
            hashVal = (a * hashVal + bytes[i]) % LARGE_PRIME;
        }
        return hashVal;
    }

    public long recompute(byte removed, byte incoming) {
        currHashValue = (a * (currHashValue - removed * h) + incoming) % LARFE_PRIME;

        if (currHashValue < 0)
            currHashValue += LARGE_PRIME;

        return currHashValue;
    }


    public boolean containsBytesRollingHash(byte[] pattern, byte[] text) {
        if (text.length < pattern.length) {
            return false;
        }

        int m = pattern.length, n = text.length;
        byte[] initialBytes = Arrays.copyRange(text, 0, m);
        RollingHash hashFun = new RollingHash(31, initialBytes);

        long patternHashVal = hashFun.hash(pattern);
        for (int i = 0; i < n - m; i ++) {
            if (patternHashVal == hashFun.currHashValue) {
                int j = 0;
                while (j < m && pattern[j] == text[i + j])
                    j ++;
                if (j == m) return true;
            }
            if (i < n - m)
                hashFun.recompute(text[i], text[i + m]);
        }
        return false;
    }

    public boolean containsBytesFileRollingHash (byte[] pattern, File file) throws FileNotFoundException, IOException {
        FileInputStream fis = new FileInputStream(file);

        try {
            byte[] initialBytes = new byte[pattern.length];

            if (fis.read(initialBytes) != pattern.length) 
                return false;
            RollingHash hashFun = new RollingHash(31, initialBytes);
            long patternHashVal = hashFun.hash(pattern);
            if (patternHashVal == hashFun.currHashValue) return true;

            Queue<Byte> window = new LinkedList<>();
            for (int i = 0; i < initialBytes.length; i ++) {
                window.offer(initialBytes[i]);
            }

            int b;
            while ((b = fis.read()) != -1) {
                System.out.println (b);

                hashFun.recompute(window.poll(), (byte)b);
                window.offer((byte)b);
                if (patternHashVal == hashFun.currHashValue) return true;
            }
        } finally {
            fis.close();
        }
        return false;
    } 
}